Group-9
Name: Challengers
Type: Deliverable-2
Team Members: 
A R ASHIQUR RAHMAN 27420668
REENAL RANA  27326688
KUMARAN AYYAPAN RAVI  27285388
MILIND RAVINDRA PUKALE 27652887
AAKASHDEEP SINGH JAHAGIRDAR 27728131
JYOTSNA RANA  40013246
ADITHYA SAJJANAM 27723032
ARUMUGAM SHANMUGAM  40010992

D2:
Our Deliverable 2 satisfies the needed requirements along with some extra features:
Mandate requirements:
1. Player can able to start a new game.
2. Player can see the stats to know about his/her score.
3. Player can choose game series (3 or 5 games).
4. Player can see his symbol displayed when his turn comes.


Extra Features:
5. Player can enter his name and it will be displayed in the application.
