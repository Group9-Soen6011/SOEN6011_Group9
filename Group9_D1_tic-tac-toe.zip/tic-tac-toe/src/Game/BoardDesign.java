package Game;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
/**
* The program implements GUI application for TIC-TAC-TOE game that
* shows a window which allows user to choose symbols for  Game-piece of the game
*
* @author  Group 9
* @version Deliverable 1
* @since   2016-05-04
*/
public class BoardDesign {
    
    private JFrame frame;
    
    /**
    * Main Program - Launching the application.
    * @param args, default argument
    */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    BoardDesign window = new BoardDesign();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    
    /**
    * Initialize the application.
    */
    public BoardDesign() {
        initialize();
    }
    
    /**
    * Initialize design and contents of the frame.
    */
    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setForeground(new Color(75, 0, 130));
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent arg0) {
            }
        });
        frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 41));
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JButton btnNewButton = 	new JButton("X");
        btnNewButton.setForeground(Color.RED);
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                frame.dispose();
                new Controller("X");
                
            }
        });
        btnNewButton.setBounds(96, 107, 89, 23);
        frame.getContentPane().add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("O");
        
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                frame.dispose();
                new Controller("O");
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnNewButton_1.setForeground(Color.BLACK);
        btnNewButton_1.setBounds(234, 106, 89, 23);
        frame.getContentPane().add(btnNewButton_1);
        
        JLabel lblChooseSymbol = new JLabel("Choose Symbol");
        lblChooseSymbol.setForeground(new Color(0, 0, 128));
        lblChooseSymbol.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblChooseSymbol.setBounds(147, 74, 160, 23);
        frame.getContentPane().add(lblChooseSymbol);
        
        JLabel lblTictactoe = new JLabel(" TIC-TAC-TOE");
        lblTictactoe.setForeground(new Color(148, 0, 211));
        lblTictactoe.setFont(new Font("Tahoma", Font.BOLD, 25));
        lblTictactoe.setBackground(Color.BLUE);
        lblTictactoe.setBounds(121, 11, 171, 31);
        frame.getContentPane().add(lblTictactoe);
    }
    
    
}
