package testcases;

import static org.junit.Assert.*;

import org.junit.Test;

import Game.Controller.Controller;
import Game.Model.Board;
import Game.Model.GamePlay;
/**
* This test class implements test cases for the gameplay    *class
* @author team 9
* @version Assignment 4
* @date 24-05-2016
*/

public class GamePlayTestClass {
	GamePlay gp;
	Board bd;
	Controller cn;
     //This method test whether game blocks are initialized //properly
	@Test
	public void testInitializeBlock() {
		gp  =new GamePlay(bd);
		gp.initializeBlock(0, 1, 1);
		assertEquals(1, gp.blocks[0][1] );
	}
	//This method test whether game blocks are initialized //properly
	@Test
	public void testInitializeBlock2() {
		gp  =new GamePlay(bd);
		gp.initializeBlock(2, 2, 1);
		assertNotEquals(2, gp.blocks[2][2] );
	}
	//This method test whether controller class passing right //aruguments
	@Test
	public void testControllerCtor() {
		cn = new Controller("X");
		assertEquals("X",cn.sym);
	
	}

	
}
