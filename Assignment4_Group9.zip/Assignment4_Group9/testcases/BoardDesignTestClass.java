package testcases;

import static org.junit.Assert.*;

import org.junit.Test;

import Game.Model.Board;
/**
* This test class implements test cases for the board design   *class
* @author team 9
* @version Assignment 4
* @date 24-05-2016
*/

public class BoardDesignTestClass {
	Board brd;
     // The method test whether player turns are alternating //properly
	@Test
	public void testPlayerTurns(){
		brd = new Board("X");
		boolean flag=true;
		if(brd.alternateTurns(true)==1){
			flag = true;
		}else
			flag = false;
		assertTrue(flag);
	}
//The method test whether player turns are alternating properly
	@Test
	public void testPlayerTurns_2(){
		brd = new Board("X");
		boolean flag=true;
		if(brd.alternateTurns(flag)==2){
			flag = true;
		}else
			flag = false;
		
		assertFalse(flag);
	}
//The method checks whether game is resetting and removing 
//all the peices from the board
	@Test
	public void testResetGame()
	{
		brd = new Board("O");
		brd.resetGame();
		assertEquals(false,brd.playerTurn);
	}

}
