package testcases;
import static org.junit.Assert.*;

import org.junit.Test;

import Game.Model.Board;
/**
* This test class implements test cases for the board class
* @author team 9
* @version Assignment 4
* @date 24-05-2016
*/

public class BoardTestClass {

	Board brd;
     //This method check whether player turn gets updated upon   //initializing  
	@Test
	public void testInitialize(){
		brd = new Board("O");
		brd.initializeGame();
	   boolean flag =  brd.playerTurn;
	   assertEquals(false,flag);
		
	}
	//This method check whether symbols are properly intialized 
     @Test
	public void testConstructor() {
		brd = new Board("X");
		String symbol = brd.symbol;
		String symbol2 = brd.symbol2;
		assertEquals("X", symbol );
		assertEquals("O", symbol2);
	}	
     //This method check whether symbols are properly intialized 
	@Test
	public void testConstructor_2() {
		brd = new Board("O");
		String symbol = brd.symbol;
		String symbol2 = brd.symbol2;
		assertEquals("O", symbol );
		assertEquals("X", symbol2);
	}
	
	
}
