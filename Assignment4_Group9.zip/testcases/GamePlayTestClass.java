package testcases;

import static org.junit.Assert.*;

import org.junit.Test;

import Game.Controller.Controller;
import Game.Model.Board;
import Game.Model.GamePlay;

public class GamePlayTestClass {
	GamePlay gp;
	Board bd;
	Controller cn;
	@Test
	public void testInitializeBlock() {
		gp  =new GamePlay(bd);
		gp.initializeBlock(0, 1, 1);
		assertEquals(1, gp.blocks[0][1] );
	}
	
	@Test
	public void testInitializeBlock2() {
		gp  =new GamePlay(bd);
		gp.initializeBlock(2, 2, 1);
		assertNotEquals(2, gp.blocks[2][2] );
	}
	
	@Test
	public void testControllerCtor() {
		cn = new Controller("X");
		assertEquals("X",cn.sym);
	
	}

	
}
