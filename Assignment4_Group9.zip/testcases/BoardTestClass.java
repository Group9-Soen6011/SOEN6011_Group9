package testcases;
import static org.junit.Assert.*;

import org.junit.Test;

import Game.Model.Board;

public class BoardTestClass {

	Board brd;
	
	@Test
	public void testInitialize(){
		brd = new Board("O");
		brd.initializeGame();
	   boolean flag =  brd.playerTurn;
	   assertEquals(false,flag);
		
	}
	@Test
	public void testConstructor() {
		brd = new Board("X");
		String symbol = brd.symbol;
		String symbol2 = brd.symbol2;
		assertEquals("X", symbol );
		assertEquals("O", symbol2);
	}
	@Test
	public void testConstructor_2() {
		brd = new Board("O");
		String symbol = brd.symbol;
		String symbol2 = brd.symbol2;
		assertEquals("O", symbol );
		assertEquals("X", symbol2);
	}
	
	
}
