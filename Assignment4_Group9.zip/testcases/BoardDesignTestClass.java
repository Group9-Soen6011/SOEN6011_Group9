package testcases;

import static org.junit.Assert.*;

import org.junit.Test;

import Game.Model.Board;

public class BoardDesignTestClass {
	Board brd;
	@Test
	public void testPlayerTurns(){
		brd = new Board("X");
		boolean flag=true;
		if(brd.alternateTurns(true)==1){
			flag = true;
		}else
			flag = false;
		assertTrue(flag);
	}
	@Test
	public void testPlayerTurns_2(){
		brd = new Board("X");
		boolean flag=true;
		if(brd.alternateTurns(flag)==2){
			flag = true;
		}else
			flag = false;
		
		assertFalse(flag);
	}
	@Test
	public void testResetGame()
	{
		brd = new Board("O");
		brd.resetGame();
		assertEquals(false,brd.playerTurn);
	}

}
