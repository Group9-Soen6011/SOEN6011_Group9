package Game.Controller;

import java.awt.*;
import javax.swing.*;

import Game.Model.Board;
import Game.View.Menu;
/**
* The class which controls other the board design classes
*
* @author  Group 9
* @version Deliverable 1
* @since   2016-05-04
*/

public class Controller extends JFrame {
    
    private static final long serialVersionUID = 1L;
    private Board GameBoard;
    private Menu buttons;
    
    public Controller(String symbol){
        setLayout(new BorderLayout());
        
        GameBoard = new Board(symbol);
        buttons = new Menu();
        
        buttons.SetObject(GameBoard);
        
        add(GameBoard, BorderLayout.CENTER);
        add(buttons, BorderLayout.NORTH);
        
        setVisible(true);
        setSize(350, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}