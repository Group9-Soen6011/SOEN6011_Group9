package Game.Model;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
* The program implements GUI application for TIC-TAC-TOE game that
* shows design window of all blocks involved with the game and allows user
* click the buttons to enable Game-play
*
* @author  Group 9
* @version Deliverable 1
* @since   2016-05-04
*/
public class Board extends JPanel implements ActionListener {
    
    
    private static final long serialVersionUID = 1L;
    private JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9; // Buttons
    private boolean playerTurn = false;
    private String symbol="";
    private String symbol2="";
    
    /**
    * Parameterized constructor which initialize game Board of the Tic-tac-toe
    * @param sym, symbol of the Game piece
    *
    */
    public Board(String sym) {
        symbol = sym;
        if(symbol=="X")
        {
            symbol2= "O";
        }
        else
            symbol2="X";
        setLayout(new GridLayout(3, 3));
        
        btn1 = new JButton("");
        btn2 = new JButton("");
        btn3 = new JButton("");
        btn4 = new JButton("");
        btn5 = new JButton("");
        btn6 = new JButton("");
        btn7 = new JButton("");
        btn8 = new JButton("");
        btn9 = new JButton("");
        
        initializeGame();
      
        add(btn1);
        add(btn2);
        add(btn3);
        add(btn4);
        add(btn5);
        add(btn6);
        add(btn7);
        add(btn8);
        add(btn9);
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        btn5.addActionListener(this);
        btn6.addActionListener(this);
        btn7.addActionListener(this);
        btn8.addActionListener(this);
        btn9.addActionListener(this);
        
        
    }
    /**
    * Intialize the game buttons and display text
    */
    public void initializeGame() {
        
        initializeTextName();
        disableAllButtons(true);
        
        playerTurn = false; 
    }
    
    public void initializeTextName(){
        
        btn1.setText("");
        btn2.setText("");
        btn3.setText("");
        btn4.setText("");
        btn5.setText("");
        btn6.setText("");
        btn7.setText("");
        btn8.setText("");
        btn9.setText("");
        
        btn1.setBackground(Color.WHITE);
        btn2.setBackground(Color.WHITE);
        btn3.setBackground(Color.WHITE);
        btn4.setBackground(Color.WHITE);
        btn5.setBackground(Color.WHITE);
        btn6.setBackground(Color.WHITE);
        btn7.setBackground(Color.WHITE);
        btn8.setBackground(Color.WHITE);
        btn9.setBackground(Color.WHITE);
    }
    
    /**
    * Reset the Game
    */
    public void resetGame() {
        
        initializeGame();
        
    }
    
    /**
    * Enables Action Listener when button is pressed/clicked
    */
    public void actionPerformed(ActionEvent E) {
        
        JButton pressed = (JButton) E.getSource();
        
        /*
        if any button is pressed the value is sent to GameArray class
        */
        if (pressed == btn1) {
            setText(pressed, playerTurn);     // chaneg button text to "X" or "O" based on player turn
            alternateTurns(playerTurn); // Swithch Turns
            btn1.setForeground(Color.RED);
            
            disableButtons(btn1); // Disable pressed Button
            
        } else if (pressed == btn2) {
            
            setText(pressed, playerTurn);
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            btn2.setForeground(Color.RED);
            disableButtons(btn2);
        } else if (pressed == btn3) {
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            disableButtons(btn3);
            
        } else if (pressed == btn4) {
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            disableButtons(btn4);
            
        } else if (pressed == btn5) {
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            disableButtons(btn5);
            
        } else if (pressed == btn6) {
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            disableButtons(btn6);
        } else if (pressed == btn7) {
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            disableButtons(btn7);
        } else if (pressed == btn8) {
            
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            disableButtons(btn8);
        } else if (pressed == btn9) {
            setText(pressed, playerTurn);
            alternateTurns(playerTurn);
            disableButtons(btn9);
        }
        
    }
    /**
    * Method which switches between two players
    * @param flag, enable and disable each players turn 
    * @return the players turn
    */
    public int alternateTurns(boolean flag) {
        
        // if the past player was false(player 1) then swith to true(player 2)
        System.out.println();
        
        if (flag == true) {
            playerTurn = false;
            return 1;
            
        } else if (flag == false) {
            playerTurn = true;
            return 2;
        } else {
            return 3;
        }
        
    }
    
    /**
    * Method which displays symbol 'X' or 'O' in the board
    * @param button Jbutton for setting text and background color
    * @param flag switches betwen players
    */
    public void setText(JButton button, boolean flag) {
        if (flag == true) {
            button.setText(symbol2);
            button.setBackground(Color.BLACK);
            
        } else if (flag == false) {
            button.setText(symbol);
            button.setBackground(Color.WHITE);
        }
   }
    
    /**
    * Method disable buttons in the board
    * @param button setting the JButton
    */
    public void disableButtons(JButton button) {
       button.setEnabled(false);
    }
    
    /**
    * Method disable all the buttons in the board
    * @param flag switches betwen players
    */
    public void disableAllButtons(boolean flag) {
        
        btn1.setEnabled(flag);
        btn2.setEnabled(flag);
        btn3.setEnabled(flag);
        btn4.setEnabled(flag);
        btn5.setEnabled(flag);
        btn6.setEnabled(flag);
        btn7.setEnabled(flag);
        btn8.setEnabled(flag);
        btn9.setEnabled(flag);
    }
 }