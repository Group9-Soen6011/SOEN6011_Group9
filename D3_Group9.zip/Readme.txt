Group-9
Name: Challengers
Type: Deliverable-3
Team Members: 
A R ASHIQUR RAHMAN 27420668
REENAL RANA  27326688
KUMARAN AYYAPAN RAVI  27285388
MILIND RAVINDRA PUKALE 27652887
AAKASHDEEP SINGH JAHAGIRDAR 27728131
JYOTSNA RANA  40013246
ADITHYA SAJJANAM 27723032
ARUMUGAM SHANMUGAM  40010992

D3:
Our Deliverable 3 satisfies the needed requirements along with some extra features:
Mandate requirements:
1. Game will provide Background music
2. Game will provide gifts to the winner.
3. Player can different levels of game
4. Player can choose symbol X or O


Extra Features:
5. Computer evaluate heuristics in depths of 2 or 3 using MinMax Algorithm.
