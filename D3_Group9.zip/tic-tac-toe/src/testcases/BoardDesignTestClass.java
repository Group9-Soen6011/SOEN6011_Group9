package testcases;

import static org.junit.Assert.*;

import org.junit.Test;

import Game.Model.Board;
/**
* This test class implements test cases for the board design class
* @author k_ravi
* @version Deliverable 3
*/
public class BoardDesignTestClass {
	Board brd;
	//The method test whether player turns are alternating properly
	@Test
	public void testPlayerTurns(){
		String val[]={"X",""};
		brd = new Board(val);
		boolean flag=true;
		if(brd.alternateTurns(true)==1){
			flag = true;
		}else
			flag = false;
		assertTrue(flag);
	}
	//The method test whether player turns are alternating properly
	@Test
	public void testPlayerTurns_2(){
		String val[]={"X",""};
		brd = new Board(val);
		boolean flag=true;
		if(brd.alternateTurns(flag)==2){
			flag = true;
		}else
			flag = false;
		
		assertFalse(flag);
	}
	//The method test whether player turns are alternating properly
	@Test
	public void testResetGame()
	{
		String val[]={"O",""};
		brd = new Board(val);
		brd.resetGame();
		assertEquals(false,brd.playerTurn);
	}
}
