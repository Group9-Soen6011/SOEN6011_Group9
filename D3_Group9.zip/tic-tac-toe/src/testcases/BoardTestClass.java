package testcases;
import static org.junit.Assert.*;
import org.junit.Test;
/**
* This test class implements test cases for the board class
* @author k_ravi
* @version Deliverable 3
* @date 24-05-2016
*/
import Game.Model.Board;
public class BoardTestClass {
	Board brd;
	//This method check whether player turn gets updated upon initializing 
	@Test
	public void testInitialize(){
		String val[]={"O",""};
		brd = new Board(val);
		brd.initializeGame();
	   boolean flag =  brd.playerTurn;
	   assertEquals(false,flag);
		
	}
	//This method check whether symbols are properly initialized 
	@Test
	public void testConstructor() {
		String val[]={"X",""};
		brd = new Board(val);
		String symbol = brd.playerSymbol;
		String symbol2 = brd.p2_symbol;
		assertEquals("X", symbol );
		assertEquals("O", symbol2);
	}
	//This method check whether symbols are properly initialized 
	@Test
	public void testConstructor_2() {
		String val[]={"X",""};
		brd = new Board(val);
		String symbol = brd.playerSymbol;
		String symbol2 = brd.p2_symbol;
		assertEquals("O", symbol2);
		assertEquals("X", symbol);
	}
}
