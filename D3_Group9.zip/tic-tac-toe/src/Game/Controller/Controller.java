package Game.Controller;

import java.awt.*;
import javax.swing.*;

import Game.Model.Board;
import Game.View.GameMode;
import Game.View.Menu;
/**
* The class which controls other the board design classes
*
* @author  k_ravi
* @version Deliverable 3
* @since   2016-05-04
*/
public class Controller extends JFrame {
    
    private static final long serialVersionUID = 1L;
    private Board gbd;
    public  GameMode gm;
    private Menu buttons;
    public String sym="";
    public Controller(String[] attributes){
        setLayout(new BorderLayout());
        //gm = new GameMode(playerSymbol);
        gbd = new Board(attributes);
        buttons = new Menu();
        buttons.SetObject(gbd);
        add(gbd, BorderLayout.CENTER);
        add(buttons, BorderLayout.NORTH);
        setVisible(true);
        setSize(350, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        sym = attributes[0];
        
    }
    
}