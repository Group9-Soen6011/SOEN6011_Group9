package Game.View;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.Color;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import Game.Model.Board;

import java.io.File;
import java.net.URL;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
* The program implements GUI application for TIC-TAC-TOE game that
* shows a window which allows user to choose symbols for  Game-piece of the game
*
* @author  k_ravi
* @version Deliverable 3
* @since   2016-05-04
*/
public class BoardDesign {
    
    private JFrame frame;
    
    /**
    * Main Program - Launching the application.
    * @param args, default argument
    * @throws handles IO exception
    */
    public static void main(String[] args) throws Exception {
        File f = new File("./music/bgm.wav");
        URL url = f.toURI().toURL();
        Clip clip = AudioSystem.getClip();
        AudioInputStream ais = AudioSystem.
        getAudioInputStream(url);
        clip.open(ais);
        clip.loop(Clip.LOOP_CONTINUOUSLY);
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        try {
                            
                            BoardDesign window = new BoardDesign();
                            window.frame.setVisible(true);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }
    
    /**
    * Initialize the application.
    */
    public BoardDesign() {
        initialize();
    }
    /**
    * Initialize design and contents of the frame.
    */
    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setBackground(new Color(0, 0, 0));
        frame.getContentPane().setForeground(new Color(75, 0, 130));
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent arg0) {}
        });
        frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 41));
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        JButton btnNewButton = new JButton("X");
        btnNewButton.setBackground(new Color(255, 255, 255));
        btnNewButton.setForeground(new Color(0, 0, 128));
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	 try {
						Board.playSound();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
            	frame.dispose();
                new GameMode("X");
                
            }
        });
        
        btnNewButton.setBounds(102, 132, 89, 23);
        frame.getContentPane().add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("O");
        btnNewButton_1.setBackground(new Color(255, 255, 255));
        
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	 try {
						Board.playSound();
					} catch (Exception ee) {
						// TODO Auto-generated catch block
						ee.printStackTrace();
					}
                frame.dispose();
                new GameMode("O");
            }
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnNewButton_1.setForeground(new Color(0, 0, 128));
        btnNewButton_1.setBounds(230, 131, 89, 23);
        frame.getContentPane().add(btnNewButton_1);
        
        JLabel lblChooseSymbol = new JLabel("Choose Symbol");
        lblChooseSymbol.setForeground(new Color(245, 255, 250));
        lblChooseSymbol.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblChooseSymbol.setBounds(147, 74, 160, 23);
        frame.getContentPane().add(lblChooseSymbol);
        
        JLabel lblTictactoe = new JLabel(" TIC-TAC-TOE");
        lblTictactoe.setForeground(new Color(255, 245, 238));
        lblTictactoe.setFont(new Font("Tahoma", Font.BOLD, 25));
        lblTictactoe.setBackground(new Color(47, 79, 79));
        lblTictactoe.setBounds(121, 11, 171, 31);
        frame.getContentPane().add(lblTictactoe);
    }
    
    
}