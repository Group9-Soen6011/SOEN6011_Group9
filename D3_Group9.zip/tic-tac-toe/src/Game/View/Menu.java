package Game.View;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import Game.Model.Board;
/**
* The class which shows design window of the menus like
* help, exit, reset
*
* @author  k_ravi
* @version Deliverable 3
* @since   2016-05-04
*/
public class Menu extends JPanel {
    
    private static final long serialVersionUID = -2306983591296880306L;
    private JButton exitBtn, resetBtn,helpBtn;
    private Board bd;
    /**
     * Default constructor
     */
    public Menu() {
        setLayout(new FlowLayout());
        exitBtn = new JButton("Exit");
        resetBtn = new JButton("Reset");
        helpBtn = new JButton("Help");
        exitBtn.addActionListener(new ActionListener() {
            
        public void actionPerformed(ActionEvent ae) {
                try {
                    Board.playSound();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.exit(0);
            }
        });
        helpBtn.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                try {
                    Board.playSound();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                JOptionPane.showMessageDialog(null,"Tic-tac-toe (also known as Noughts and crosses or Xs and Os)"
                
                + "\n"+" is a paper-and-pencil game for two players, X and O, who take turns marking the spaces in a 3�3 grid."
                    + "\n"+" The player who succeeds in placing three of their marks in a horizontal, vertical, or diagonal row wins the game. ");
            }
        });
        resetBtn.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                try {
                    Board.playSound();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                bd.resetGame();
             }
        });
        add(exitBtn);
        add(resetBtn);
        add(helpBtn);
    }
    /**
    * Method setting object
    * @param b object of the class Board
    */
    public void SetObject(Board b) {
        
        bd = b;
        
    }}