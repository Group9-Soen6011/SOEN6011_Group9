package Game.View;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import Game.Controller.Controller;
import Game.Model.Board;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
/**
* The program implements game design for TIC-TAC-TOE game 
*
* @author  k_ravi
* @version Deliverable 3
* @since   2016-05-04
*/
public class GameMode {
    
    private JFrame frame;
    String[] attr= new String[3];
   /**
    * Create the application.
    * @param sym, symbol
    */
    public GameMode(String sym) {
        attr[0] = sym;
        initialize();
    }
    /**
    * Initialize the contents of the frame.
    */
    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setBackground(new Color(0, 0, 0));
        frame.setVisible(true);
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JButton btnNewButton = new JButton("2 PLAYER GAME");
        btnNewButton.setBackground(new Color(255, 255, 255));
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Board.playSound();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                frame.dispose();
                attr[1] = "1";
                new Controller(attr);// pass the playerSymbol
                
            }
        });
        btnNewButton.setBounds(138, 81, 173, 23);
        frame.getContentPane().add(btnNewButton);
        JButton btnNewButton_1 = new JButton("PLAYER vs COMPUTER");
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1.setBackground(new Color(255, 255, 255));
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Board.playSound();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                btnNewButton_1.setVisible(false);
                btnNewButton.setVisible(false);
                
                chooseGameLevels();
            }
        });
        btnNewButton_1.setBounds(138, 130, 173, 23);
        frame.getContentPane().add(btnNewButton_1);
    }
    /**
     * This method implements game design for different game levels
     */
    void chooseGameLevels()
    {
        JButton btnNewButton = new JButton("Amateur");
        btnNewButton.setBackground(new Color(255, 255, 255));
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                attr[1] = "2";
                try {
                    Board.playSound();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                new Controller(attr);
                frame.dispose();
            }
        });
        btnNewButton.setBounds(138, 51, 141, 23);
        frame.getContentPane().add(btnNewButton);
        JButton btnNewButton_1 = new JButton("Intermediate");
        btnNewButton_1.setBackground(new Color(255, 255, 255));
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                attr[1] = "3";
                try {
                    Board.playSound();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                new Controller(attr);
                frame.dispose();
            }
        });
        btnNewButton_1.setBounds(138, 91, 141, 23);
        frame.getContentPane().add(btnNewButton_1);
        JButton btnNewButton_2 = new JButton("Pro");
        btnNewButton_2.setBackground(new Color(255, 255, 255));
        btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 11));
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                attr[1] = "4";
                try {
                    Board.playSound();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                new Controller(attr);
                frame.dispose();
            }
        });
        btnNewButton_2.setBounds(138, 131, 141, 23);
        frame.getContentPane().add(btnNewButton_2);
    }
}
