package Game.Model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
/**
* The program implements AI heuristics for finding best move for the computer using min-max Algorithm
*
* @author  k_ravi	
* @version Deliverable 3
* @since   2016-05-04
*/
public class BestMoveUsingMinMax {
    boolean flag=true;
    boolean flag2=true;
    public String[][] tempArray;
    int currentX, currentY,prevX,prevY;
    String[] nextmoves;
    String[] moves = new String[9];
    String[] tempMoves;
    String playerSymbol;
    String computerSymbol;
    int depth;
    HashMap < String, Integer > map = new HashMap < String, Integer > (){{ put("btn1", 0); put("btn2", 1); put("btn3", 2);
    put("btn4", 3); put("btn5", 4); put("btn6", 5);put("btn7", 6); put("btn8", 7); put("btn9", 8);}};
    ArrayList<Integer> minList;
    int tem=0;
    Map<Integer, Integer> map2 = new HashMap <Integer, Integer>();
    /**
    * This method allows  players to choose their next best move efficiently and play their game based on it
    * @return integer array holding moves
    */
    int[] calculate(int depth,String p1_symbol,String compSymbol,String[] remainingMoves, String[] moves){ 
    	nextmoves = remainingMoves;
        playerSymbol = p1_symbol;
        computerSymbol = compSymbol;
        minList = new ArrayList<Integer>();
        ArrayList < String > arrayList =  new ArrayList < String > (Arrays.asList(remainingMoves));
        calculateMinmax(depth,compSymbol,moves, arrayList);
        return finalResult();
    }
    
    int[] calculateMinmax(int depth,String placingSymbol,String[] tempMov, ArrayList<String> arrList){
        System.out.println("Symbol "+placingSymbol);
        int bestScore=0,bestIndex=0;
        ArrayList<String> tempArrList= new ArrayList<String>();
        tempArrList.addAll(arrList);
        if(arrList.isEmpty() || depth == 0){
            return new int[]{evaluateHeuristics(tempMov)};
        } else {
            for(String move: tempArrList){
                if(placingSymbol==computerSymbol) {
                    int index = map.get(move);
                    tempMov[index] = computerSymbol;
                    arrList.remove(move);
                    int currentScore = calculateMinmax(depth-1,playerSymbol,tempMov, arrList)[0];
                    System.out.println("computer's current score : " +currentScore + " the index "+index );
                    if(flag){
                        System.out.println("check");
                        bestScore = currentScore;
                        bestIndex = index;
                        flag = false;
                    }if(currentScore > bestScore){
                        bestScore = currentScore;
                        bestIndex = index;
                    }
                    tempMov[index]="";  //rollback after checking its possiblities
                } else {
                    int index = map.get(move);
                    tempMov[index] = playerSymbol;
                    arrList.remove(move);
                    int currentScore = calculateMinmax(depth-1,computerSymbol,tempMov, arrList)[0];
                    System.out.println("player's current score : " +currentScore + " the index "+index );
                    if(flag2){
                        System.out.println("check2");
                        bestScore = currentScore;
                        bestIndex = index;
                        flag2 = false;
                        minList.add(bestScore);
                        map2.put(bestScore, bestIndex);
                        System.out.println("putting val 1st " +bestIndex);
                    } if(currentScore<bestScore) {
                        bestScore = currentScore;
                        bestIndex = index;
                    } if(map2.containsKey(bestScore)) {
                        System.out.println("xxx");
                        map2.remove(bestScore);
                        minList.add(bestScore);
                        System.out.println("putting val " +bestIndex);
                        map2.put(bestScore, bestIndex);
                    } else {
                        minList.add(bestScore);
                        System.out.println("putting val 3 rd " +bestIndex);
                        map2.put(bestScore, index);
                    }
                    tempMov[index]="";  //rollback after checking its possiblities
                 }
            }
        }
        return new int[]{bestScore, bestIndex};
    }
    /**
    * This method returns maximum or minimum score one player/computer could get based on the heuristics applied
    * @return integer value denoting max/min points for a player/computer.
    */
    int evaluateHeuristics(String[] move)
    {
        
        int value=0;
        // calculating values of computer/player's pieces from rows, columns and diagonal of the board
        int x = 0, y = 1, z = 2;
        for(int i=0;i<8;i++)
        {
            if(i==3){ x = 0; y = x + 3; z = x + 6;}
            if(i>3 && i<=5){ x = x + 1;  y = x + 3 ; z = x + 6; }
            if(i==6){ x = 4; y = x + 4; z = x - 4; }
            if(i==7){ x = 4; y = x + 2; z = x - 2; }
            // System.out.println("i value: "+ i+" x value= "+ x+" y val= "+ y+" Z val ="+ z);
            if(move[x]==computerSymbol && move[y] == computerSymbol && move[z] == computerSymbol){
                value = value + 1000;
            }
            else if(move[x]==playerSymbol && move[y] == playerSymbol && move[z] == playerSymbol){
                value = value - 1000;
            }
            else if((move[x]==computerSymbol && move[y] == computerSymbol) || (move[y] == computerSymbol && move[z] == computerSymbol) || (move[z] == computerSymbol && move[x] == computerSymbol)){
                value = value + 100;
            }
            else if((move[x]==playerSymbol && move[y] == playerSymbol) || (move[y] == playerSymbol && move[z] == playerSymbol) || (move[z] == playerSymbol && move[x] == playerSymbol)){
                value = value - 100;
                
            }
            else if(move[x]==computerSymbol || move[y] == computerSymbol || move[z] == computerSymbol){
                value = value + 10;
            }
            else if(move[x]==playerSymbol || move[y] == playerSymbol || move[z] == playerSymbol){
                value = value - 10;
            }
            
            if(i<3){ x = x + 3; y = x + 1; z = x + 2 ;}
        }
        return value;
    }
    /**
     * This method returns the final value
     * @return integer arrays containing best score and best move
     */
    int[] finalResult() {
    	int minScore = Collections.min(minList);
        return (new int[]{minScore,map2.get(minScore)});
    }
}
