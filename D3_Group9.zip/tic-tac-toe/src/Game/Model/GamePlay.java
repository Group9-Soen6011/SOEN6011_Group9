package Game.Model;

import java.util.Random;
import javax.swing.*;
/**
* The program implements game play for TIC-TAC-TOE game 
*
* @author  k_ravi
* @version Deliverable 3
* @since   2016-05-04
*/
public class GamePlay {
       
    public Board bd;
    public int blocks[][];
    public int mark = 0;
    public boolean turn;
    public JButton Pressed;
    String[] gifts = {"you won $100 dollar!!","you won ticket to amusement park!!","you won giftcard for StarBucks!!",
    "you won giftcard for subway!!","you won 50% cashback on tuition fees!!"};
    
    public GamePlay(Board B) {
        blocks = new int[3][3];
        bd = B;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                blocks[i][j] = 0;
            }
        }
    }
    public boolean initializeBlock(int i, int j, int count) {
        blocks[i][j] = count;
        return checkWinningScenario(count);
    }
    void displayWinningMsg(){
         int x = new Random().nextInt(gifts.length);
        String random = gifts[x];
        if(mark == 1){
            JOptionPane.showMessageDialog(bd, "CONGRATULATIONS : Player 1 '"+  bd.playerSymbol+"' won the Game"+ "\n" + random);
        }
        else if (mark == 2){
            JOptionPane.showMessageDialog(bd, "CONGRATULATIONS : Player 2 '"+ bd.p2_symbol+"' won the Game"+ "\n" + random);
        }
    }
    public boolean checkWinningScenario(int Marker) {
       mark = Marker;
        if ((blocks[0][0] == Marker && blocks[0][1] == Marker && blocks[0][2] == Marker) || (blocks[1][0] == Marker && blocks[1][1] == Marker && blocks[1][2] == Marker) || (blocks[2][0] == Marker && blocks[2][1] == Marker && blocks[2][2] == Marker)) {
            
            bd.disableAllButtons(false);
            return true;
            
        } else if ((blocks[0][0] == Marker && blocks[1][0] == Marker && blocks[2][0] == Marker) || (blocks[0][1] == Marker && blocks[1][1] == Marker && blocks[2][1] == Marker) || (blocks[0][2] == Marker && blocks[1][2] == Marker && blocks[2][2] == Marker)) {
            
            bd.disableAllButtons(false);
            return true;
        } else if ((blocks[0][0] == Marker && blocks[1][1] == Marker && blocks[2][2] == Marker) || (blocks[2][0] == Marker && blocks[1][1] == Marker && blocks[0][2] == Marker)) {
            
            bd.disableAllButtons(false);
            return true;
        }
        return false;
    }
}
