package Game.Model;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import sun.audio.*;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;

/**
* The program implements GUI application for TIC-TAC-TOE game that
* shows design window of all blocks involved with the game and allows user
* click the buttons to enable Game-play
*
* @author  k_ravi
* @version Deliverable 3
* @since   2016-05-04
*/
public class Board extends JPanel implements ActionListener {
    
    public static final long serialVersionUID = 1L;
    public JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9; // Buttons
    public boolean playerTurn = false;
    public  String playerSymbol="" ;
    public String p2_symbol="";
    public int count = 1;
    public GamePlay gp;
    public String[] unusedBlocks;
    public String[] arr = {"btn1","btn2","btn3","btn4","btn5","btn6","btn7","btn8","btn9"};
    public String[] moves = new String[9];
    BestMoveUsingMinMax bnm;
    ArrayList < String > arrayList;
    HashMap < Integer, String > map = new HashMap < Integer, String > (){{ put(0,"btn1"); put(1,"btn2"); put(2,"btn3");
    put(3,"btn4"); put(4,"btn5"); put(5,"btn6");put(6,"btn7"); put(7,"btn8"); put(8,"btn9");}};
    public String choice = "";
    /**
    * Parameterized constructor which initialize game Board of the Tic-tac-toe
    * @param attributes, stores the best index and best move
    *
    */
    public Board(String[] attributes) {
    	bnm = new BestMoveUsingMinMax();
    	unusedBlocks = new String[9];
    	java.util.Arrays.fill(moves,"");
    	arrayList = new ArrayList < String > (Arrays.asList(arr));
        playerSymbol = attributes[0];
        choice = attributes[1];
        if(playerSymbol=="X"){
            p2_symbol= "O";
        }
        else
            p2_symbol="X";
        setLayout(new GridLayout(3, 3));
        
        btn1 = new JButton("");
        btn2 = new JButton("");
        btn3 = new JButton("");
        btn4 = new JButton("");
        btn5 = new JButton("");
        btn6 = new JButton("");
        btn7 = new JButton("");
        btn8 = new JButton("");
        btn9 = new JButton("");
        
        initializeGame();
      
        add(btn1);
        add(btn2);
        add(btn3);
        add(btn4);
        add(btn5);
        add(btn6);
        add(btn7);
        add(btn8);
        add(btn9);
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        btn5.addActionListener(this);
        btn6.addActionListener(this);
        btn7.addActionListener(this);
        btn8.addActionListener(this);
        btn9.addActionListener(this);
     }
    /**
    * Intialize the game buttons and display text
    */
    public void initializeGame() {
    	gp = new GamePlay(this);
        initializeTextName();
        disableAllButtons(true);
        count = 1;
        playerTurn = false; 
    }
    /**
     * This method intialize the button text to default text
     */
    public void initializeTextName(){
        btn1.setText("");
        btn2.setText("");
        btn3.setText("");
        btn4.setText("");
        btn5.setText("");
        btn6.setText("");
        btn7.setText("");
        btn8.setText("");
        btn9.setText("");
       
        btn1.setBackground(Color.WHITE);
        btn2.setBackground(Color.WHITE);
        btn3.setBackground(Color.WHITE);
        btn4.setBackground(Color.WHITE);
        btn5.setBackground(Color.WHITE);
        btn6.setBackground(Color.WHITE);
        btn7.setBackground(Color.WHITE);
        btn8.setBackground(Color.WHITE);
        btn9.setBackground(Color.WHITE);
    }
    /**
    * Reset the Game
    */
    public void resetGame() {
    	arrayList = new ArrayList < String > (Arrays.asList(arr));
        initializeGame();
    }
    /**
     * This method implements computer moves and its gameplay
     */
     public void computerAction()
    {
    	boolean flag = false;
    	String selectedButton="";
    	unusedBlocks = arrayList.toArray(new String[arrayList.size()]);
    	int x = new Random().nextInt(unusedBlocks.length);
    	if(choice == "2")
    	{   	
    	    	selectedButton = unusedBlocks[x];
    	}
    	else if(choice == "3"){ 
    		int val[] = bnm.calculate(2, playerSymbol, p2_symbol, unusedBlocks, moves);
    		x = val[1];
    		System.out.println("the best score and index are "+val[0] + " " +x);
    		selectedButton = map.get(x);
    	}
    	else if(choice == "4"){
    		int val[] = bnm.calculate(3, playerSymbol, p2_symbol, unusedBlocks, moves);
    		x = val[1];
    		System.out.println("the best score and index are "+val[0] + " " +x);
    		selectedButton = map.get(x);
    	}
    	//Exceptional case
    	ArrayList<String> at = new ArrayList < String > (Arrays.asList(unusedBlocks));
		if(!at.contains(selectedButton)){
		  	selectedButton = unusedBlocks[x];
		}
		if (selectedButton == "btn1") {
    		flag =	gp.initializeBlock(0, 0, count);
        	setText(btn1, playerTurn);     // change buttons symbol from "X" to "O" based on player turn
            count = alternateTurns(playerTurn); // Switch Turns
            arrayList.remove("btn1");
            disableButtons(btn1); // Disable pressed Button
            moves[0]=p2_symbol;
		} else if (selectedButton == "btn2") {
        	
        	flag =gp.initializeBlock(0, 1, count);
            setText(btn2, playerTurn);
                count = alternateTurns(playerTurn);
                arrayList.remove("btn2");
                    disableButtons(btn2);
                    moves[1]=p2_symbol;
                   
        } else if (selectedButton == "btn3") {
        	flag = gp.initializeBlock(0, 2, count);
            setText(btn3, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn3");
            disableButtons(btn3);
            System.out.println("3");
            moves[2]=p2_symbol;
            
        } else if (selectedButton == "btn4") {
        	flag =gp.initializeBlock(1, 0, count);
            setText(btn4, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn4");
            disableButtons(btn4);
            moves[3]=p2_symbol;
            
        } else if (selectedButton == "btn5") {
        	flag =gp.initializeBlock(1, 1, count);
            setText(btn5, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn5");
            disableButtons(btn5);
            moves[4]=p2_symbol;
        } else if (selectedButton == "btn6") {
        	flag =gp.initializeBlock(1, 2, count);
            setText(btn6, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn6");
            disableButtons(btn6);
            moves[5]=p2_symbol;
        } else if (selectedButton == "btn7") {
        	flag =gp.initializeBlock(2, 0, count);
            setText(btn7, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn7");
            disableButtons(btn7);
            moves[6]=p2_symbol;
        } else if (selectedButton == "btn8") {
        	flag =gp.initializeBlock(2, 1, count);
            setText(btn8, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn8");
            disableButtons(btn8);
            moves[7]=p2_symbol;
        } else if (selectedButton == "btn9") {
        	flag =	gp.initializeBlock(2, 2, count);
            setText(btn9, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn9");
            disableButtons(btn9);
            moves[8]=p2_symbol;
        }
    	if(flag){
    		gp.displayWinningMsg();
    	}
    
    }
     /**
      * This method implements background music for the game
      * @throws Exception when format is different
      */
     public static synchronized void playSound() throws Exception {
        new Thread(new Runnable() { 
        	 File f=new File("./music/click.wav");
        		URL url = f.toURI().toURL();
            public void run() {
              try {
                Clip clip = AudioSystem.getClip();
                AudioInputStream ais = AudioSystem.
                    	getAudioInputStream( url );
                clip.open(ais);
                clip.start(); 
              } catch (Exception e) {
                System.err.println(e.getMessage());
              }
            }
          }).start();
    }
    /**
    * Enables Action Listener when button is pressed/clicked
    */
    public void actionPerformed(ActionEvent E) {
        
        JButton pressed = (JButton) E.getSource();
      
        boolean flag = false;
        /*
        if any button is pressed the value is sent to GameArray class
        */
        if (pressed == btn1) {
        	flag = gp.initializeBlock(0, 0, count);
            setText(pressed, playerTurn);      // change buttons symbol from "X" to "O" based on player turn
            count = alternateTurns(playerTurn); // Switch Turns
            arrayList.remove("btn1");
            disableButtons(btn1); // Disable pressed Button
            moves[0]=playerSymbol;
        } else if (pressed == btn2) {
        	flag = gp.initializeBlock(0, 1, count);
            setText(pressed, playerTurn);
                count = alternateTurns(playerTurn);
                arrayList.remove("btn2");
                    disableButtons(btn2);
                    moves[1]=playerSymbol;
        } else if (pressed == btn3) {
        	flag = 	gp.initializeBlock(0, 2, count);
            setText(pressed, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn3");
            disableButtons(btn3);
            moves[2]=playerSymbol;
        } else if (pressed == btn4) {
        	flag = gp.initializeBlock(1, 0, count);
            setText(pressed, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn4");
            disableButtons(btn4);
             moves[3]=playerSymbol;
        } else if (pressed == btn5) {
        	flag = 	gp.initializeBlock(1, 1, count);
            setText(pressed, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn5");
            disableButtons(btn5);
            moves[4]=playerSymbol;
        } else if (pressed == btn6) {
        	flag = 	gp.initializeBlock(1, 2, count);
            setText(pressed, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn6");
            disableButtons(btn6);
            moves[5]=playerSymbol;
        } else if (pressed == btn7) {
        	flag = 	gp.initializeBlock(2, 0, count);
            setText(pressed, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn7");
            disableButtons(btn7);
            moves[6]=playerSymbol;
        } else if (pressed == btn8) {
        	flag = 	gp.initializeBlock(2, 1, count);
            setText(pressed, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn8");
            disableButtons(btn8);
            moves[7]=playerSymbol;
        } else if (pressed == btn9) {
        	flag = gp.initializeBlock(2, 2, count);
            setText(pressed, playerTurn);
            count = alternateTurns(playerTurn);
            arrayList.remove("btn9");
            moves[8]=playerSymbol;
        }
        if(arrayList.isEmpty()){
        	JOptionPane.showMessageDialog(this,"Game is DRAWN");
        	resetGame();
        	return;
        }
        if(flag){
            	gp.displayWinningMsg();
        }
         if(choice != "1" && !flag ){
        	computerAction();
        }
    }
    /**
    * Method which switches between two players
    * @param flag, enable and disable each players turn 
    * @return the players turn
    */
    public int alternateTurns(boolean flag) {
    	try {
 			playSound();
 		} catch (Exception e) {
 			e.printStackTrace();
 		}
        // if the past player was false(player 1) then switch to true(player 2)
        System.out.println();
        
        if (flag == true) {
            playerTurn = false;
            return 1;
            
        } else if (flag == false) {
            playerTurn = true;
            return 2;
        } else {
            return 3;
        }
    }
    /**
    * Method which displays playerSymbol 'X' or 'O' in the board
    * @param button Jbutton for setting text and background color
    * @param flag switches betwen players
    */
    public void setText(JButton button, boolean flag) {
    	
        if (flag == true) {
            button.setText(p2_symbol);
            button.setBackground(Color.BLACK);
            
        } else if (flag == false) {
            button.setText(playerSymbol);
            button.setBackground(Color.WHITE);
        }
   }
    /**
    * Method disable buttons in the board
    * @param button setting the JButton
    */
    public void disableButtons(JButton button) {
       button.setEnabled(false);
    }
    
    /**
    * Method disable all the buttons in the board
    * @param flag switches betwen players
    */
    public void disableAllButtons(boolean flag) {
        btn1.setEnabled(flag);
        btn2.setEnabled(flag);
        btn3.setEnabled(flag);
        btn4.setEnabled(flag);
        btn5.setEnabled(flag);	
        btn6.setEnabled(flag);
        btn7.setEnabled(flag);
        btn8.setEnabled(flag);
        btn9.setEnabled(flag);
    }
	
 }