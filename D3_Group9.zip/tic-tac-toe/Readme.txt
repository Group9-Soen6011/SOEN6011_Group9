Group-9
Name: Challengers
Type: Deliverable-1
Team Members: 
A R ASHIQUR RAHMAN 27420668
REENAL RANA  27326688
KUMARAN AYYAPAN RAVI  27285388
MILIND RAVINDRA PUKALE 27652887
AAKASHDEEP SINGH JAHAGIRDAR 27728131
JYOTSNA RANA  40013246
ADITHYA SAJJANAM 27723032
ARUMUGAM SHANMUGAM  40010992

D1:
Our Deliverable 1 satisfies the needed requirements along with some extra features:
Mandate requirements:
1. 3x3 board will be displayed
2. Player can exit the game.
3. Player can choose symbol 'X' or 'O'.
4. Player can reset the game.

Extra Features:
5. player click help menu to know background information of the game.
6. Player can resize the board.
7. Different Background color will be displayed for symbols 'X' and 'O' in the board
 